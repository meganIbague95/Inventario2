package com.inventario.esquema;

public class TipoInventario {
	private Integer idTipoInvetario;
	private String nombre;
	
	public TipoInventario() {
	}
	
	public Integer getIdTipoInvetario() {
		return idTipoInvetario;
	}
	public void setIdTipoInvetario(Integer idTipoInvetario) {
		this.idTipoInvetario = idTipoInvetario;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
}
